import { ApiPromise, WsProvider } from "@polkadot/api";
import { Keyring } from "@polkadot/keyring";
import config from "../config.json";
import keys from "../test_keys.json";

function sendSubstrate(api, account, data, nonce) {
  const tx = api.tx.datalog.record(data);
  return tx.signAndSend(account, { nonce });
}

async function loop(api, pairs, nonce) {
  const list = [];
  for (const pair of pairs) {
    list.push(sendSubstrate(api, pair.pair, config.data, pair.nonce + nonce));
  }
  return Promise.all(list);
}

async function main() {
  const api = await ApiPromise.create({
    provider: new WsProvider(config.api),
    types: {
      LiabilityIndex: "Vec<u8>",
      TechnicalReport: "Vec<u8>",
      Parameter: "Vec<u8>",
      Record: "Vec<u8>",
      TechnicalParam: "Vec<u8>",
      EconomicalParam: "{}",
      ProofParam: "MultiSignature",
    },
  });
  const keyring = new Keyring({
    ss58Format: 42,
    type: "sr25519",
  });
  try {
    const pairs = [];

    for (const m of keys.keys) {
      const pair = keyring.addFromUri(Object.values(m)[0]);
      const nonce = await api.rpc.system.accountNextIndex(pair.address);
      console.log(pair.address, Number(nonce));
      pairs.push({ pair, nonce: Number(nonce) });
    }

    for (let index = 0; index < config.i; index++) {
      console.log(`start step #${index}`);
      console.time(`step #${index}`);
      try {
        await loop(api, pairs, index);
      } catch (error) {
        console.log(error);
      }
      console.timeEnd(`step #${index}`);
      console.log(`end step #${index}`);
    }
    console.log("end");
    process.exit(0);
  } catch (error) {
    console.log("error", error);
  }
}
main();
