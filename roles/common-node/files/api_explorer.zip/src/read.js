import { ApiPromise, WsProvider } from "@polkadot/api";
import config from "../config.json";

async function main() {
  const api = await ApiPromise.create({
    provider: new WsProvider(config.api),
    types: {
      LiabilityIndex: "Vec<u8>",
      TechnicalReport: "Vec<u8>",
      Parameter: "Vec<u8>",
      Record: "Vec<u8>",
      TechnicalParam: "Vec<u8>",
      EconomicalParam: "{}",
      ProofParam: "MultiSignature",
    },
  });

  await api.rpc.chain.subscribeNewHeads((header) => {
    api.rpc.chain.getBlockHash(header.number).then((hash) => {
      api.rpc.chain.getBlock(hash, (block) => {
        console.log(Number(header.number), block.block.extrinsics.length);
      });
    });
  });
}
main();
